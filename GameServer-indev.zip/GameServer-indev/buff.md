## List of buffs

Description buff | Buffname
------------ | -------------
Zhonya hourglass (or wooglets witchcap) | `WoogletsWitchcap`
Sadism (R DrMundo) | `Sadism`
Light Binding (Q Lux) | `LuxLightBindingMis`
Dragon Slayer (Drake) | `S5Test_DragonSlayerBuff`
? | `S5Test_TowerWrath`
? | `S5_FakeEyes`
Ice Blast (E Nunu) | `Iceblast`
Aspect of the Dragon (Killing 5 drake) | `S5_AspectOfTheDragon`
Banshee's Veil | `BansheesVeil`
TODO | `BootsHomeguardSpeed`
TODO | `BilgewaterCutlass`
TODO | `BlackOmen`
TODO | `Slow`
Red buff ("neutralmonster_buf_red_offense.troy" particle) | `BlessingoftheLizardElder`
Ghost | `Haste`
? | `Bloodmail2`
Ignite(?) | `Burning`
Burning Agone (W DrMundo) | `BurningAgony`
 (E TF) ("cardmaster_stackready.troy" particle) | `CardMasterStack`
Red card (Z TF) | `CardmasterSlow`
(Chogat?) | `Carnivore`
Catalyst ("env_manaheal.troy" particle) | `CatalystHeal`
? | `Cripple`
DFG Debuff | `DeathfireGraspSpell`
Defensive Ball Curl (W Rammus) | `DefensiveBallCurl`
Destiny (R TF) | `Destiny`
Bump (Q Alistar) | `Pulverize`
Dragon burn (5 stacks drake) | `DragonBurning`
Camouflage (Passive Teemo) | `Camouflage`
Dark Binding (Q Morgana) (when hit bit projectile) | `DarkBinding`
Dark Wind (E Fiddlesticks) | `Silence`
? | `DragonVisionBuff`
Drain (W Fiddlesticks)| `Drain`
Elexir of Iron | `ElixirOfIron`
Elixir Of Rage | `ElixirOfRage`
Elixir Of Ruin | `ElixirOfRuin`
Elixir Of Sorcery | `ElixirOfSorcery`
Elixir Of Wrath | `ElixirOfWrath`
(Targon?) | `EmblemofValor`
Empower (W Jax) | `EmpowerTwo`