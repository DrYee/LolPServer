﻿using ENet;
using LeagueSandbox.GameServer.Logic.Packets;
using LeagueSandbox.GameServer.Logic.Players;

namespace LeagueSandbox.GameServer.Core.Logic.PacketHandlers.Packets
{
    class HandleGameNumber : IPacketHandler
    {
        private Game _game = Program.ResolveDependency<Game>();
        private PlayerManager _playerManager = Program.ResolveDependency<PlayerManager>();

        public bool HandlePacket(Peer peer, byte[] data)
        {
            var world = new WorldSendGameNumber(1, _playerManager.GetPeerInfo(peer).Name);
            return _game.PacketHandlerManager.sendPacket(peer, world, Channel.CHL_S2C);
        }
    }
}
